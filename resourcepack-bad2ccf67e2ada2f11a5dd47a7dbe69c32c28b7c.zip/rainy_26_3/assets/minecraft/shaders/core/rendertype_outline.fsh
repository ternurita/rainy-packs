#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in vec4 vertexColor;
layout(location = 1) in vec2 texCoord0;

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }
    vec3 outline = ColorModulator.rgb * vertexColor.rgb;
    // Rainy Network: the LIGHT_PURPLE glow (team colour of Hanami-tagged
    // players, tm_hanami) is drawn light pink #FFA6CF to match the bow's art.
    // Every other glow colour is untouched.
    // 26.3+ copy (pack overlay rainy_26_3): 26.3 rewrote the shader syntax.
    if (all(lessThan(abs(outline - vec3(1.0, 0.33333, 1.0)), vec3(0.02)))) {
        outline = vec3(1.0, 0.65098, 0.81176);
    }
    fragColor = vec4(outline, ColorModulator.a);
}
